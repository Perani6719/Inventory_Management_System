import { Routes } from '@angular/router';
import { Login } from './components/login/login';
import { Layout } from './components/layout/layout';
import { Landing } from './components/dashboard/landing/landing';
import { ProductComponent } from './components/dashboard/add-product/add-product';
import { ShelfComponent } from './components/dashboard/shelf/shelf';
import { Category } from './components/dashboard/category/category';
import { Register } from './components/register/register';
import { RoleGuard } from './components/guards/role-guard';
import { ProductShelf } from './components/dashboard/product-shelf/product-shelf';
import { ShelfMetricsComponent } from './components/dashboard/shelf-metrics/shelf-metrics';
import { StockRequestComponent } from './components/dashboard/stock-request/stock-request';
import { DeliveryLogComponent } from './components/dashboard/delivery-log-status/delivery-log-status'; // ✅ Corrected import
import { CreateRequestAlertComponent } from './components/dashboard/create-request-alert/create-request-alert';
import { AllRequestsComponent } from './components/dashboard/all-requests/all-requests';
import { WarehouseDashboardComponent } from './components/dashboard/warehouse/warehouse-dashboard';
import { ReplenishmentAlertsComponent } from './components/dashboard/replenishment-alerts/replenishment-alerts';
import { PredictDepletionComponent } from './components/dashboard/predict-depletion/predict-depletion';
 
export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: Login },

  // ✅ Warehouse dashboard route (outside layout)
  {
    path: 'warehouse-dashboard',
    component: WarehouseDashboardComponent,
    canActivate: [RoleGuard],
    data: { roles: ['warehouse'] }
  },

  // ✅ Delivery Log route (outside layout for flexibility)
  

  // ✅ Shared layout for admin, manager, staff
  {
    path: '',
    component: Layout,
    canActivateChild: [RoleGuard],
    children: [
      { path: 'landing', component: Landing, data: { roles: ['admin', 'manager', 'staff'] } },
      { path: 'add-product', component: ProductComponent, data: { roles: ['admin', 'manager', 'staff'] } },
      { path: 'add-category', component: Category, data: { roles: ['admin', 'manager', 'staff'] } },
      { path: 'add-shelf', component: ShelfComponent, data: { roles: ['admin', 'manager', 'staff'] } },
      { path: 'register', component: Register, data: { roles: ['admin', 'manager'] } },
      { path: 'product-shelf', component: ProductShelf, data: { roles: ['admin', 'manager', 'staff'] } },
      { path: 'shelf-metrics', component: ShelfMetricsComponent, data: { roles: ['admin', 'manager', 'staff'] } },
      { path: 'create-request-alert', component: CreateRequestAlertComponent, data: { roles: ['admin', 'manager', 'staff'] } },
      { path: 'all-requests', component: AllRequestsComponent, data: { roles: ['admin', 'manager', 'staff'] } },
      { path: 'replenishment-alerts', component: ReplenishmentAlertsComponent, data: { roles: ['admin', 'manager', 'staff'] } },
      { path: 'predict-depletion',component:PredictDepletionComponent,data:{roles:['admin','manager','staff']} },
      { path: 'delivery-log',component: DeliveryLogComponent,canActivate: [RoleGuard],data: { roles: ['admin', 'manager', 'staff'] }
  }
    ]
  },

  // ✅ Fallback route
  { path: '**', redirectTo: 'login' }
];
